
import { GoogleGenAI, Type } from "@google/genai";
import { Customer } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeCustomerBase = async (customers: Customer[]) => {
  const customerSummary = customers.map(c => ({
    name: c.name,
    status: c.status,
    value: c.value,
    company: c.company
  }));

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analise a seguinte base de clientes de um CRM e forneça insights estratégicos de negócio: ${JSON.stringify(customerSummary)}`,
    config: {
      systemInstruction: "Você é um consultor sênior de BI e CRM. Forneça insights práticos sobre crescimento, retenção e valor do cliente em português brasileiro. Use Markdown para formatação.",
    }
  });

  return response.text;
};

export const generateCustomerAdvice = async (customer: Customer) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Como posso melhorar o relacionamento com este cliente específico? Dados: ${JSON.stringify(customer)}`,
    config: {
      systemInstruction: "Seja conciso, empático e focado em vendas estratégicas.",
    }
  });

  return response.text;
};
